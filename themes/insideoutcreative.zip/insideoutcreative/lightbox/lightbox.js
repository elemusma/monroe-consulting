lightbox.option({
    'resizeDuration': 200,
    'wrapAround': true
  })