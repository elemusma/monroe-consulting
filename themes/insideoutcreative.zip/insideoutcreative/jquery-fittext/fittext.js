// $("#fittext1").fitText();
// $(".fittext2").fitText(.45);
// $(".fittext3").fitText(.37);
// $(".fittext4").fitText(.25);
// $(".fittext5").fitText(.45);
// $(".fittext6").fitText(.865);
// $(".fittext7").fitText(.2);
// $(".fittext8").fitText(.575);
// $("#fittext3").fitText(1.1, { minFontSize: '50px', maxFontSize: '75px' });
$(".page-title").fitText(1.5);
// $(".subtitle").fitText(2.5);

// $("#home-subtext").fitText(1.11);
// alert('hello');