<?php


echo '<section class="pb-5 position-relative">';
echo '<div class="container">';
echo '<div class="row justify-content-center">';
echo '<div class="col-md-7 text-center d-flex justify-content-center align-items-center flex-wrap pt-4 pb-4" style="background:#f2f2f2;">';

echo '<span class="h2 mr-md-2 mb-0 text-gray thin">Join the conversation.</span>';

echo '<div class="ml-md-2">';
echo get_template_part('partials/si');
echo '</div>';

echo '</div>';
echo '</div>';
echo '</div>';
echo '</section>';


?>